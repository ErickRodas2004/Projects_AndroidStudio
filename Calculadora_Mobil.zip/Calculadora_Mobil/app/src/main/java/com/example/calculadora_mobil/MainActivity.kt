package com.example.calculadora_mobil

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextnumber1 = findViewById<EditText>(R.id.editTextNumber1)
        val editTextnumber2 = findViewById<EditText>(R.id.editTextNumber2)
        val text_resultado = findViewById<TextView>(R.id.text_resultado)

        val btnSuma = findViewById<Button>(R.id.button_suma)
        val btnResta = findViewById<Button>(R.id.button_resta)
        val btnMultiplicacion = findViewById<Button>(R.id.button_multiplicacion)
        val btnDivicion= findViewById<Button>(R.id.button_division)

        fun getNumeros(): Pair<Double, Double>?{
            val num1 = editTextnumber1.text.toString()
            val num2 = editTextnumber2.text.toString()

            return if(num1.isNotEmpty() && num2.isNotEmpty()){
                Pair(num1.toDouble(), num2.toDouble())
            } else{
                Toast.makeText(this, "Por favor ingresar ambos números", Toast.LENGTH_SHORT).show()
                null
            }
        }

        btnSuma.setOnClickListener {
            getNumeros()?.let{
                val result = it.first+ it.second
                text_resultado.text = "Resultado: $result"
            }
        }
        btnResta.setOnClickListener {
            getNumeros()?.let{
                val result = it.first - it.second
                text_resultado.text = "Resultado: $result"
            }
        }
        btnMultiplicacion.setOnClickListener {
            getNumeros()?.let {
                val result = it.first * it.second
                text_resultado.text = "Resultado: $result"
            }
        }
        btnDivicion.setOnClickListener {
            getNumeros()?.let {
                if(it.second != 0.0){
                val result = it.first / it.second
                text_resultado.text = "Resultado: $result"
                }else{
                    Toast.makeText(this,"No se puede dividir entre cero", Toast.LENGTH_SHORT).show()
                }
            }

        }
    }

}